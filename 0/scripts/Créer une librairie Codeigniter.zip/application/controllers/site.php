<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site extends CI_Controller {

	public function index()
	{
		$this->load->library('seo');
		$this->load->helper('url');
		
		$titre = 'Un Tutoriel PHP héhé';
		
		echo site_url('controller/fonction/'.$this->seo->url($titre));
	}
}
?>