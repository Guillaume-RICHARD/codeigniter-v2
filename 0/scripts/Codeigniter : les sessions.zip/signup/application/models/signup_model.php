<?php
class Signup_model extends CI_Model
{
  
  function __construct()
  {
    parent::__construct();
  }
  
  function signup($data)
  {
    $this->db->insert('membres',$data);
  }
  
  function check_id($pseudo,$pass)
  {
    $this->db->where('pseudo',$pseudo);
    $this->db->where('pass',sha1($pass));
    $q = $this->db->get('membres');
    if($q->num_rows()>0)
    {
      return true;
    }
  }
}
?>