<!DOCTYPE html>
<html>
  <meta charset="UTF-8">
  <head>
    <link rel="stylesheet" href="<?php echo base_url();?>css/style.css" />
    <title></title>
  </head>
  <body>
    <div id="content">
      
      <h1><?php echo $titre;?></h1>
      
      <?php if(isset($success)):?>
      <div class="success"><?php echo $success;?></div>
      <?php endif;?>
      
      
      <?php echo form_open('signup');?>
      
      <label for="pseudo">Pseudo:</label>
      <?php echo form_error('pseudo','<span class="error">','</span>');?>
      <input type="text" name="pseudo" value="<?php echo set_value('pseudo');?>" />
      
      <label for="email">Email:</label>
      <?php echo form_error('email','<span class="error">','</span>');?>
      <input type="text" name="email" value="<?php echo set_value('email');?>" />
      
      <label for="pass">Mot de passe:</label>
      <?php echo form_error('pass','<span class="error">','</span>');?>
      <input type="password" name="pass" value="<?php echo set_value('pass');?>" />
      
      <input type="submit" value="Envoyer" />
      
      <?php echo form_close();?>
      
      <?php echo anchor('signup/login','Me connecter');?>
      
    </div>
  </body>
</html>