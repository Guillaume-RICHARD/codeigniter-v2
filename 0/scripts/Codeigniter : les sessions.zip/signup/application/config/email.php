<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.free.fr';
$config['smtp_port'] = 25;
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';