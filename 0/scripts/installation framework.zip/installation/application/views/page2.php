<!DOCTYPE html>
<html>
  <meta charset="UTF-8">
  <head>
    <link rel="stylesheet" href="<?php echo base_url();?>css/style.css" />
    <title><?php echo $title;?></title>
  </head>
  <body>
    <h1><?php echo $heading;?></h1>
    
    <?php echo anchor('site','Retour accueil');?>
  </body>
</html>