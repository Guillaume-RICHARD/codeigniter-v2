<!DOCTYPE html>
<html>
  <meta charset="UTF-8">
  <head>
    <link rel="stylesheet" href="<?php echo base_url();?>css/style.css" />
    <title><?php echo $title;?></title>
  </head>
  <body>
    
    <h1><?php echo $heading;?></h1>
    
    <?php echo anchor('site/page2','Page 2');?>
    
    <!--
    <h1>Bienvenue sur le site</h1>
    
    <p>Voici un premier tuto!</p>
  -->
  </body>
</html>