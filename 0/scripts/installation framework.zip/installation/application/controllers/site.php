<?php

class Site extends CI_Controller{
  
  function __construct()
  {
    parent:: __construct();
  }
  
  function index()
  {
    $data['title'] = 'Codeigniter: installation';
    $data['heading'] = 'Bienvenue sur le tutoriel';
    $this->load->view('accueil',$data);
  }
  
  function page2()
  {
    $data['title'] = 'Page 2';
    $data['heading'] = 'Bienvenue sur la page 2';
    $this->load->view('page2',$data);
  }
}

?>