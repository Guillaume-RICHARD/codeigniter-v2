<?php
class Site extends CI_Controller {

	public function index()
	{
		$this->load->model('sitemodel');
		
		$data['rows'] = $this->sitemodel->get_all();
		$this->load->view('home',$data);
	}
}
?>