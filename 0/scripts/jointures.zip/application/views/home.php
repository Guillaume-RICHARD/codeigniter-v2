<!DOCTYPE html> 
<html lang="fr"> 
<head>
<meta charset="UTF-8">
  <head>
  <title></title>
  </head>
  <body>
	  <?php if($rows):
	  foreach($rows as $r):?>
	  
	  <h2><?php echo $r->titre;?></h2>
	  
	  <p><?php echo $r->description;?></p>
	  
	  <p>Auteur : <?php echo $r->pseudo;?></p>
	  
	  <p>Categorie : <?php echo $r->nom_categorie;?></p>
	  
	  <?php endforeach; endif;?>
  </body>
</html>