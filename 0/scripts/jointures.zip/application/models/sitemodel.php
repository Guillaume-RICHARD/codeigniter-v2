<?php

class Sitemodel extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}
	
	function get_all()
	{
		$this->db->select('*')
		->from('tutoriels')
		->join('membres','membres.id = tutoriels.membre_id','left')
		->join('categories','categories.id = tutoriels.categorie_id','left');
		$q = $this->db->get();
		if($q->num_rows()>0)
		{
			foreach($q->result() as $row)
			{
				$data[]  = $row;
			}
			return $data;
		}
	}
}

?>