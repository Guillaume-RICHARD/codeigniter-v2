<?php

class Cron extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		
		if($this->input->is_cli_request() === false)
		{
			die('cli only');
		}
	}

	public function demo($message = '')
	{
		$f = fopen(FCPATH.'demo.txt','a+');
		fwrite($f,date('d/m/Y H:i:s')."\n");
		fwrite($f,$message."\n");
		fclose($f);
	}

}