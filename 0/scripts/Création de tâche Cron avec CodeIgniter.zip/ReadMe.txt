Résumé de la mise en place d'un tâche cron avec CodeIgniter

1/ création du controlleur
2/ création de la méthode
3/ Ajout de la vérification dans le constructeur du controlleur (Classe réservée à un appel en ligne de commande)
4/ test de l'appel en cli 
	php /<project_path>/index.php <controller>/<method> [<param>...]

5/ Ajout de la tâche cron
	crontab -e
	<minute> <heure> <jour> <mois> <jour_semaine> <ligne_de_commande>

	Rappel:
		entré en mode edition : touche "i"
		quitter le mode édition : touche "echap"
		sauvegarder et quitter : touche ":wq" (write & quit)

6/ Vérification du cron
	crontab -l