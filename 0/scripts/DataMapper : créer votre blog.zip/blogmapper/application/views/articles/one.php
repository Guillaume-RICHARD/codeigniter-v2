<!DOCTYPE html> 
<html lang="fr"> 
<head>
<meta charset="UTF-8">
  <head>
	<link rel="stylesheet" href="<?php echo base_url();?>css/style.css">
  <title></title>
  </head>
  <body>
	<div id="content">
		
		<header>
			<h1>Mon blog</h1>
		</header>
		
		<div id="main">
			
			<?php if(!empty($article)):?>
			
			<div class="article">
			  <h2><?php echo $article->titre;?></h2>
			  
			  <p><?php echo $article->description;?></p>
			  
			  <div class="date"><?php echo date('d/m/Y',strtotime($article->date_article));?></div>
			</div>
			
			<?php endif;?>
			
			<?php foreach($article->comment->all as $c):?>
			
			<div class="comment">
			  
			  <div class="pseudo"><?php echo $c->pseudo;?></div>
			  <p class="com"><?php echo $c->commentaire;?></p>
			  <div class="date"><?php echo $c->date_comment;?></div>
			  
			</div>
			
			<?php endforeach;?>
			
			<div id="form">
			  <?php echo form_open('articles/comment/'.$article->id);?>
			  <label for="pseudo">Pseudo</label>
			  <input type="text" name="pseudo">
				
				
			  <label for="commentaire">Commentaire</label>
			  <textarea name="commentaire"></textarea>
			  
			  <input type="submit" value="Envoyer" />
			  
			  <?php echo form_close();?>
			</div>
		</div>
		
	</div>
  </body>
</html>