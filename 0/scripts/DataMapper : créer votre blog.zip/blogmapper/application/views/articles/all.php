<!DOCTYPE html> 
<html lang="fr"> 
<head>
<meta charset="UTF-8">
  <head>
	<link rel="stylesheet" href="<?php echo base_url();?>css/style.css">
  <title></title>
  </head>
  <body>
	<div id="content">
		
		<header>
			<h1>Mon blog</h1>
		</header>
		
		<div id="main">
			
			<?php if(!empty($articles)):
			foreach($articles as $a):?>
			
			<div class="article">
			  <h2><?php echo $a->titre;?></h2>
			  
			  <p>
			  <?php echo nl2br(character_limiter($a->description,250));?></p>	
			  </p>
			  
			  <span class="read"><a href="<?php echo site_url('articles/view/'.strtolower(url_title(convert_accented_characters($a->titre))).'/'.$a->id);?>">Lire la suite-></a></span>
			  <div class="date"><?php echo date('d/m/Y',strtotime($a->date_article));?></div>
			</div>
			
			<?php endforeach; endif;?>
		</div>
		
	</div>
  </body>
</html>