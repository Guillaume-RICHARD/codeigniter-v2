<!DOCTYPE html> 
<html lang="fr"> 
<head>
<meta charset="UTF-8">
  <head>
	<link rel="stylesheet" href="<?php echo base_url();?>css/style.css">
  <title></title>
  </head>
  <body>
	<div id="content">
		
		<header>
			<h1>Administration</h1>
		</header>
		
		<div id="main">
			
			<?php if(isset($success)):?>
			
			<div class="success"><?php echo $success;?></div>
			
			<?php endif;?>
			
			<?php if(isset($errors)):?>
			<div class="error"><?php echo $errors;?>
			<?php endif;?>
			
			<?php echo form_open('articles/add');?>
			
			<label for="titre">Titre:</label>
			<input type="text" name="titre" value="<?php ($this->input->post('titre')) ? $this->input->post('titre') : '';?>">
			
			<label for="description">Description:</label>
			
			<textarea name="description"><?php ($this->input->post('description')) ? $this->input->post('description') : '';?></textarea>
			
			<input type="submit" value="Envoyer">
			
			<?php echo form_close();?>
			
		</div>
		
	</div>
  </body>
</html>