<?php

class Article extends DataMapper{
	var $has_many = array('comment');
	
	var $validation = array(
		array(
			'field'=>'titre',
			'label'=>'Titre',
			'rules'=>array('required','min_length'=>3)
		),
		
		array(
			'field'=>'description',
			'label'=>'Description',
			'rules'=>array('required','trim')
		)
	);
	
	
	function Article()
	{
		parent::DataMapper();
	}
	
}

?>