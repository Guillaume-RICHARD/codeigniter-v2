<?php

class Comment extends DataMapper{
	
	var $has_one = array('article');
	
	var $validation = array(
		array(
			'field'=>'pseudo',
			'label'=>'Pseudo',
			'rules'=>array('required')
		),
		
		array(
			'field'=>'commentaire',
			'label'=>'Commentaire',
			'rules'=>array('required','trim')
		)
	);
	
	
	function Comment()
	{
		parent::DataMapper();
	}
	
}

?>