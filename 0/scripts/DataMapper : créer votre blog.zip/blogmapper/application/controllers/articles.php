<?php

class Articles extends CI_Controller{
	
	public function index()
	{
		$this->load->view('articles/admin');
	}
	
	function add()
	{
		$a = new Article();
		$a->titre = $this->input->post('titre');
		$a->description = $this->input->post('description');
		
		if($a->save())
		{
			$data['success'] = 'Article ajouté';
			$this->load->view('articles/admin',$data);
		}
		else
		{
			$data['errors'] = $a->error->string;
			$this->load->view('articles/admin',$data);
		}
	}
	
	function all()
	{
		$a = new Article();
		
		$a->order_by('id','desc');
		$data['articles'] = $a->get()->all;
		
		$this->load->view('articles/all',$data);
	}
	
	function view()
	{
		if(!$this->uri->segment(4)){redirect(site_url('articles/all'));exit;}
		
		$a = new Article();
		
		$a->where('id',$this->uri->segment(4));
		$data['article'] = $a->get();
		
		$this->load->view('articles/one',$data);
	}
	
	function comment()
	{
		if(!$this->uri->segment(3)){redirect(site_url('articles/all'));exit;}
		
		$c = new Comment();
		$c->pseudo = $this->input->post('pseudo');
		$c->commentaire = $this->input->post('commentaire');
		
		$a = new Article();
		$a->where('id',$this->uri->segment(3))->get();
		
		if($c->save($a->all))
		{
			redirect($_SERVER['HTTP_REFERER']);
		}
		else
		{
			echo $c->error->string;
		}
	}
	
}

?>