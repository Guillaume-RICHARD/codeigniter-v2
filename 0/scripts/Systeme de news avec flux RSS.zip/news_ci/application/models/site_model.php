<?php
class Site_model extends Model {

	function getAll()
	{
		$this->db->order_by('id','desc');
		$q = $this->db->get('news');
		
		if($q->num_rows()>0)
		{
			foreach($q->result() as $row)
			{
				$data[] = $row;
			}
			return $data;
		}
	}

}