<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css" media="screen" />
<head>
  <title><?php echo $titre;?></title>
</head>
<body>
  
  <div id="content">
    <div id="rss">
      <a href="<?php echo site_url();?>/rss"><img src="<?php echo base_url();?>css/images/rss.png" /></a>
    </div>
    
    <h3>Les nouveaux tutos de simpledev</h3>
    
    <?php foreach($rows as $r) :?>
    
    <h2><a href="<?php echo $r->url;?>"><?php echo $r->titre;?></a></h2>
    
    <p><?php echo $r->contenu;?></p>
    <p class="date"><?php echo date('d/m/Y H:i', strtotime($r->date));?></p>
    
    <?php endforeach;?>
    
  </div>
  
</body>
</html>