<?php
class Rss extends Controller {
  
  function index()
  {
    $this->load->model('site_model');
    $data['encoding'] = 'utf-8';
    $data['feed_name'] = 'Nouveaux tutos';
    $data['feed_url'] = 'http://fr.tuto.com/';
    $data['page_description'] = 'Les nouveaux tutos de simpledev';
    $data['page_language'] = 'fr';
    $data['creator_email'] = 'nettutoriel@gmail.com';
    $data['posts'] = $this->site_model->getAll();
    header("Content-type: application/rss+xml");
    $this->load->view('rss',$data);
  }
  
}