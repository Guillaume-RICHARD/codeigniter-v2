<?php
class Site extends Controller {
  
  function index()
  {
    $this->load->model('site_model');
    $data['rows'] = $this->site_model->getAll();
    $data['titre'] = 'Nouveaux tutoriels';
    
    $this->load->view('accueil',$data);
  }
  
}