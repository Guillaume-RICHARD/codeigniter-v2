<?php
class Blog extends CI_Controller {

  function __construct()
  {
    parent::__construct();
  }

  function index()
  {
    $data['results'] = $this->blog_model->get_all();
    $data['titre'] = 'Bienvenue sur mon blog';
    $this->load->view('accueil',$data);
  }
}
?>