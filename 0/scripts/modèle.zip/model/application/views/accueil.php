<!DOCTYPE html>
<html>
  <meta charset="UTF-8">
  <head>
    <title></title>
  </head>
  <body>
    
    <h1><?php echo $titre;?></h1>
    
    <?php if($results != null):
    foreach($results as $r):?>
    
    <h2><?php echo $r->titre;?></h2>
    
    <p><?php echo $r->contenu;?></p>
    
    <div class="date"><?php echo date('d/m/Y H:i',strtotime($r->date));?></div>
    
    <?php endforeach; endif;?>
    
  </body>
</html>